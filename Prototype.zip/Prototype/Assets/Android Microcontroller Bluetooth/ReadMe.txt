We're so close to a new Major Version upgrade for the BtLibrary. The BtLibrary now works much better than the current library in every way, So try it out.

Note : The BtLibrary available inside the "BtLibrary" folder of this Asset.

########### For any questions :
########### Email : techtweaking@gmail.com
