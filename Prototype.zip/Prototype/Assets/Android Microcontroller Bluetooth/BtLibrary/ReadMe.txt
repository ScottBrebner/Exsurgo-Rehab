The BtLibrary [ Release Candidate ]

The following library offers more functionality and control, please check out the Manual.


## Manual and Documentation : http://yahyabadran.github.io


## When to use this library :
Basicly this library is more mature and works better than the current library.

1) It can connect multiple devices at the same time.
2) Higher bit rate.
2) Android to Android connection (Server - Client).
3) you have more chance of making a successful connection with this library, because it has a self connection error handling mechanism.


##########(1)Warnning###########
Btlibrary shouldn't co-exist with the current library, you either need to delete all the files related to the Android/Bluetooth library, and then install the BtLibrary, or import the BtLib library to an empty project.
##########(2)######
Just Import the Package in this folder to your project, and read the setup guide that comes with it.